package com.example.digitkey;

import java.util.HashMap;

public class user {
    //String password;
    //String userName;
    //HashMap<String, String> passwords = new HashMap<>();
    //public user (String userName, String password){
        //this.password = password;
        //this.userName = userName;
    //}
   // public void addPassword(String userName, String password){
        //passwords.put(userName, password);
    //}

   // public String getUserName(){
       // return userName;
    //}

   // public String getPassword(){
        //return password;
    //}

}
