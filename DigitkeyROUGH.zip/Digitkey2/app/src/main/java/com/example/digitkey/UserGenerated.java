package com.example.digitkey;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class UserGenerated extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_generated);
    }


    public void Save(View view) {
        EditText userName = (EditText)findViewById(R.id.user);
        EditText password = (EditText)findViewById(R.id.password);
        String usernameStr = (String)userName.getText().toString();
        String passwordStr = (String)password.getText().toString();
        try {
            FileOutputStream out = openFileOutput("password2.txt", Activity.MODE_PRIVATE);
            out.write(passwordStr.length());
            for(int i=0; i <passwordStr.length();i++){
                out.write((int) (passwordStr.charAt(i)));}
            out.write(usernameStr.length());
            for(int i=0; i <usernameStr.length();i++){
                out.write((int) (usernameStr.charAt(i)));}
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Intent i = new Intent(this,
                Passwords.class);
        startActivity(i);
    }

    public void generate(View view) {
        Intent i = new Intent(this,
                generated.class);
        startActivity(i);
    }

}
