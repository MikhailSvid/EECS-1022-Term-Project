package com.example.digitkey;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // sends you to Createaccount screen
    public void Create(View view) {
        Intent i = new Intent(this,
                CreateAccount.class);
        startActivity(i);
    }
    // sends you to password screen
    public void Login(View view) {
        Intent i = new Intent(this,
                Passwords.class);
        startActivity(i);
    }
}
